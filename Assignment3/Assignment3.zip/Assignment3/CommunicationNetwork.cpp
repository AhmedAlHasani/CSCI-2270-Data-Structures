#include "CommunicationNetwork.h"
#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;

CommunicationNetwork::CommunicationNetwork()
{
    head = NULL;
    tail = NULL;
}

CommunicationNetwork::~CommunicationNetwork()
{
    //dtor
}

void CommunicationNetwork::buildNetwork()
{
    City *temporary = new City("Los Angeles", NULL,""); //Start with the first city
    head = temporary; //Set head to the first city
    temporary -> next = new City("Phoenix", NULL, ""); //temporary pointer will
    temporary = temporary -> next;
    temporary -> next= new City("Denver", NULL, "");
    temporary = temporary -> next;
    temporary -> next= new City("Dallas", NULL, "");
    temporary = temporary -> next;
    temporary -> next = new City("St.Louis",NULL,"");
    temporary = temporary -> next;
    temporary -> next = new City("Chicago",NULL,"");
    temporary = temporary -> next;
    temporary -> next = new City("Atlanta",NULL,"");
    temporary = temporary -> next;
    temporary -> next = new City("Washington, DC",NULL,"");
    temporary = temporary -> next;
    temporary -> next = new City("New York",NULL,"");
    temporary = temporary -> next;
    temporary -> next = new City("Boston",NULL,"");
}

void CommunicationNetwork::printNetwork()
{
    cout << "===CURRENT PATH==="<< endl;
    City *current = head -> next;  //Q
    string message= head -> cityName;
    while (current != NULL)
    {
        cout<<message<<" -> ";
        message = current->cityName;
        current = current->next; //Q
    }
    if (current == NULL)
    {
        cout<<message<<" -> ";
    }
    cout<<"NULL"<<endl;
    cout<<"=================="<<endl;
}

void CommunicationNetwork::transmitMsg(char* myFile)
{
    ifstream myFile1;
    myFile1.open(myFile);
    if (myFile1.good())
    {
        string wordRead;
        while (!myFile1.eof())
        {
            myFile1>>wordRead;
            cout<<wordRead<<endl;
        }
    }
    else
        cout<<"File Did Not Open"<<endl;

}




